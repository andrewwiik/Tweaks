@interface CCXNonTransparentView : UIView
- (void)setBackgroundColor:(UIColor *)color;
@end