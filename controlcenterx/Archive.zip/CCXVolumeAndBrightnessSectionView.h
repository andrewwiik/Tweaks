#import "headers.h"

@interface CCXVolumeAndBrightnessSectionView : CCUIControlCenterSectionView
@end