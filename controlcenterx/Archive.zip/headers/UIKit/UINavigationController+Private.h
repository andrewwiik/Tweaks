@interface UINavigationController (Private)
@property (nonatomic,readonly) UIViewController * previousViewController; 
@end