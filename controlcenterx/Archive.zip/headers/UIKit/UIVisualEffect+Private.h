#import "_UIVisualEffectConfig.h"

@interface UIVisualEffect (Private)
@property (nonatomic,readonly) _UIVisualEffectConfig * effectConfig;
@end