@protocol WeatherCloudPersistenceDelegate
@required
-(void)cloudPersistenceDidSynchronize:(id)arg1;

@end