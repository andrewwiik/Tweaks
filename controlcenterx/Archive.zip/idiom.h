void enableFakeIdiom();
void disableFakeIdiom();