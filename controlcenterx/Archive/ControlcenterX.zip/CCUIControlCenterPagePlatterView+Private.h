@interface CCUIControlCenterPagePlatterView (CCX)
@property (nonatomic, assign) BOOL suppressRenderingMask;
@end