@interface CCXMainControlsPageView : UIView
@end