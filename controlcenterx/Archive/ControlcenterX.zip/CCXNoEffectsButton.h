#import "headers.h"

@interface CCXNoEffectsButton : CCUIControlCenterButton
- (void)updateEffects;
@end