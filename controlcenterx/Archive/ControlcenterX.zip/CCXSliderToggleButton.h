#import "headers.h"

@interface CCXSliderToggleButton : CCUIControlCenterButton
- (void)_updateEffects;
@end