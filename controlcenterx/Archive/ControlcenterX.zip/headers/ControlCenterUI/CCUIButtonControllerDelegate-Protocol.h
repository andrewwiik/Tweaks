@protocol CCUIButtonControllerDelegate
@required
-(BOOL)buttonControllerShouldUseSmallButtons:(id)arg1;
-(void)buttonController:(id)arg1 publishStatusUpdate:(id)arg2;
-(id)controlCenterSystemAgent;

@end
