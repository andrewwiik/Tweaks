@interface MPUChronologicalProgressView : UIView
@end