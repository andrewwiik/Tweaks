@protocol MPUTransportControlsViewDataSource
@required
-(id)transportControlsView:(id)arg1 buttonForControlType:(NSInteger)arg2;

@end