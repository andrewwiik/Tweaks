// @protocol CAAnimationDelegate
// @optional
// -(void)animationDidStop:(id)arg1 finished:(BOOL)arg2;
// -(void)animationDidStart:(id)arg1;

// @end