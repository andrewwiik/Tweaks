@interface CALayer (Private)
@property (assign) CGColorRef contentsMultiplyColor; 
- (void)setAllowsGroupBlending:(BOOL)allowed;

@end