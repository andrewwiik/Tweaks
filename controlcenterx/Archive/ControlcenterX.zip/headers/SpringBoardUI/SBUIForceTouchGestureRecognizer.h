@interface SBUIForceTouchGestureRecognizer : UILongPressGestureRecognizer
- (id)initWithTarget:(id)arg1 action:(SEL)arg2;
@end