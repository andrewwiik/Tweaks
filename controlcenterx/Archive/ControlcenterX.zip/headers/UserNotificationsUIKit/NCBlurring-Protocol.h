@protocol NCBlurring
@property (assign,nonatomic) CGFloat inputRadius; 
@required
-(void)setInputRadius:(CGFloat)arg1;
-(CGFloat)inputRadius;

@end