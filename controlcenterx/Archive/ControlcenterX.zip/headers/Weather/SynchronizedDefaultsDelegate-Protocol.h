@protocol SynchronizedDefaultsDelegate
@required
-(void)ubiquitousDefaultsDidChange:(id)arg1;

@end
