@protocol WFTemperatureUnitObserver
@required
-(void)temperatureUnitObserver:(id)arg1 didChangeTemperatureUnitTo:(int)arg2;

@end