@protocol CCUIButtonStackPagingViewDelegate
@required
-(void)beginSuppressingPunchOutMaskCachingForReason:(id)arg1;
-(void)endSuppressingPunchOutMaskCachingForReason:(id)arg1;
- (BOOL)isKindOfClass:(Class)arg1;
@end
