@protocol MPAVRoutingViewControllerDelegate
@optional
-(void)routingViewController:(id)arg1 didPickRoute:(id)arg2;
-(void)routingViewControllerDidUpdateContents:(id)arg1;
-(void)routingViewControllerDidShowAirPlayDebugScreen:(id)arg1;

@end