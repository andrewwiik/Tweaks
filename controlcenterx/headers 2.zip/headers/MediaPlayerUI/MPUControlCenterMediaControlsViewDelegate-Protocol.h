@protocol MPUControlCenterMediaControlsViewDelegate
@optional
-(void)mediaControlsView:(id)arg1 willTransitionToCompactView:(BOOL)arg2;
-(void)mediaControlsViewPrimaryActionTriggered:(id)arg1;

@end