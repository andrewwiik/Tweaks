#import <MediaPlayerUI/MPUNowPlayingMetadataView.h>

@interface MPUControlCenterMetadataView : MPUNowPlayingMetadataView
+(Class)labelClass;
@end