#import <MediaPlayerUI/MPUChronologicalProgressView.h>

@interface MPUControlCenterTimeView : MPUChronologicalProgressView
+(Class)timeLabelsClass;
@end