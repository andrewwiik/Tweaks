@interface SBUIActionPlatterViewController : UIViewController
-(id)initWithActions:(id)arg1 gestureRecognizer:(id)arg2 ;
@end