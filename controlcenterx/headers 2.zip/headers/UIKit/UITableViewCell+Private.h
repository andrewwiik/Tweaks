@interface UITableViewCell (Private)
-(void)_setSeparatorEffect:(id)arg1 ;
@end