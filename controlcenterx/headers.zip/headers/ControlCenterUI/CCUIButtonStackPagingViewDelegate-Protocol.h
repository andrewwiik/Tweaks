@protocol CCUIButtonStackPagingViewDelegate
@required
-(void)beginSuppressingPunchOutMaskCachingForReason:(id)arg1;
-(void)endSuppressingPunchOutMaskCachingForReason:(id)arg1;

@end
