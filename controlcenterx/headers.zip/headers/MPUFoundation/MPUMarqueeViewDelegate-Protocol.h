@protocol MPUMarqueeViewDelegate
@end