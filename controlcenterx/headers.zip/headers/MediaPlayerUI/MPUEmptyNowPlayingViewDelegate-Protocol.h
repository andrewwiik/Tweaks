@protocol MPUEmptyNowPlayingViewDelegate
@optional
-(void)emptyNowPlayingView:(id)arg1 couldNotLoadApplication:(id)arg2;

@end