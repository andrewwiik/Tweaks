@interface CALayer (Private)
- (void)setAllowsGroupBlending:(BOOL)allowed;
- (void)setContentsMultiplyColor:(CGColorRef)color;
@end