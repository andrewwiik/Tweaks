@interface SBUIIconForceTouchController : NSObject
+ (void)_addIconForceTouchController:(id)arg1;
- (id)init;
- (void)setDataSource:(id)arg1;
- (void)setDelegate:(id)arg1;
- (void)startHandlingGestureRecognizer:(id)arg1;
@end