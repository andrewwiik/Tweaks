@interface UIColor (Private)
+ (instancetype)systemRedColor;
@end