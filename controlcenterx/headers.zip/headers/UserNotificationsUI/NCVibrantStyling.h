@interface NCVibrantStyling : NSObject
+ (id)vibrantStylingWithStyle:(int)arg1;
@end