#import <Foundation/Foundation.h>

@interface IBIconHandler : NSObject
+ (IBIconHandler*)sharedHandler;
- (NSArray*)icons;
- (void)addObject:(NSString*)object;
- (void)removeObject:(NSString*)object;
- (BOOL)containsBundleID:(NSString*)bundleID;
@end
