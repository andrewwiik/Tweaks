#import "IBIconHandler.h"

@interface IBIconHandler () {
  NSMutableArray *aryItems;
}
@end

@implementation IBIconHandler
+ (IBIconHandler*)sharedHandler {
  static dispatch_once_t p = 0;
  __strong static id _sharedObject = nil;
  dispatch_once(&p, ^{
    _sharedObject = [[self alloc] init];
  });
  return _sharedObject;
}
- (NSArray*)icons {
  return aryItems;
}
- (void)addObject:(NSString*)object {
  if (!aryItems) {
    aryItems = [NSMutableArray new];
  }
  [aryItems addObject:object];
}
- (void)removeObject:(NSString*)object {
  if ([aryItems containsObject:object]) {
    [aryItems removeObject:object];
  }
}
- (BOOL)containsBundleID:(NSString*)bundleID {
  if ([aryItems containsObject:bundleID]) {
    return YES;
  } else {
    return NO;
  }
}
@end
