#import "DMNetwork.h"
#import "DMNetworksManager.h"
#import <AudioToolbox/AudioServices.h>

#define SCREEN ([UIScreen mainScreen].bounds)

@interface UIForceGestureRecognizer : UILongPressGestureRecognizer
@end

@interface SBApplicationController : NSObject
+ (id)sharedInstance;
- (id)applicationWithBundleIdentifier:(NSString *)bid;
@end
@interface SBApplicationShortcutStoreManager : NSObject
+ (instancetype)sharedManager;
- (id)shortcutItemsForBundleIdentifier:(id)arg1;
@end
@interface SBIconView : UIView
@property (nonatomic, retain) NSString *type;
@property(nonatomic) _Bool isEditing;
- (void)setUpHoppinGestures;
- (void)changeGestures;
- (void)openMenuSwipe:(UISwipeGestureRecognizer *)sender;
- (void)openMenuHold:(UILongPressGestureRecognizer *)sender;
- (void)editActivate:(UISwipeGestureRecognizer *)sender;
- (void)disableAllGestures;
- (void)_handleSecondHalfLongPressTimer:(id)arg1;
+ (CGSize)defaultIconImageSize;
- (UIImageView *)_iconImageView;
@end

@interface SBApplication : NSObject
@property(copy, nonatomic) NSArray *dynamicShortcutItems;
@property(copy, nonatomic) NSArray *staticShortcutItems;
- (NSString*)bundleIdentifier;
- (NSString*)displayName;
- (id)initWithApplicationInfo:(id)arg1 bundle:(id)arg2 infoDictionary:(id)arg3 entitlements:(id)arg4 usesVisibiliyOverride:(_Bool)arg5;
@end

@interface SBSApplicationShortcutItem : NSObject
@property (nonatomic, copy) NSString *localizedTitle;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSDictionary *userInfo;
- (void)setBundleIdentifierToLaunch:(id)arg1;
- (void)setIcon:(id)arg1;
- (void)setLocalizedSubtitle:(NSString*)arg1;
- (void)setLocalizedTitle:(NSString*)arg1;
- (void)setType:(NSString*)arg1;
- (void)setUserInfo:(id)arg1;
- (void)setUserInfoData:(id)arg1;
- (NSArray*)notAllowed;
@end

@interface SBIcon : NSObject
- (void)launchFromLocation:(int)location;
- (BOOL)isFolderIcon;// iOS 4+
- (NSString*)applicationBundleID;
- (SBApplication*)application;
- (id)generateIconImage:(int)arg1;
- (id)displayName;
-(id)leafIdentifier;
- (id)displayNameForLocation:(int)arg1;
@end

@interface SBFolder : NSObject
- (SBIcon*)iconAtIndexPath:(NSIndexPath *)indexPath;
@end

@interface SBFolderIcon : NSObject
- (SBFolder*)folder;
@end

@interface SBFolderIconView : SBIconView
@property (nonatomic, retain) NSString *type;
- (SBFolderIcon*)folderIcon;
@end


@interface SBIconView (Hoppin)
@property (nonatomic, retain) UISwipeGestureRecognizer *swipeUp;
@property (nonatomic, retain) UISwipeGestureRecognizer *swipeDown;
@property (nonatomic, retain) UISwipeGestureRecognizer *swipeUpEdit;
@property (nonatomic, retain) UISwipeGestureRecognizer *swipeDownEdit;
@property (nonatomic, retain) UILongPressGestureRecognizer *longPress;
@property (nonatomic, retain) UIForceGestureRecognizer *forcePress;
@end

@interface SBApplicationShortcutMenu : UIView
@property (nonatomic, retain) NSString *type;
@property(retain, nonatomic) SBApplication *application;
@property(nonatomic, retain) SBFolderIconView *iconView;
@property(retain ,nonatomic) id applicationShortcutMenuDelegate;
- (void)_peekWithContentFraction:(double)arg1 smoothedBlurFraction:(double)arg2;
- (void)updateFromPressGestureRecognizer:(id)arg1;
- (void)menuContentView:(id)arg1 activateShortcutItem:(id)arg2 index:(long long)arg3;
- (void)dismissAnimated:(BOOL)arg1 completionHandler:(id)arg2;
- (id)initWithFrame:(CGRect)arg1 application:(id)arg2 iconView:(id)arg3 interactionProgress:(id)arg4 orientation:(long long)arg5;
- (void)presentAnimated:(_Bool)arg1;
- (void)interactionProgressDidUpdate:(id)arg1;
- (int)maxNumberOfShortcuts;
- (SBFolderIconView*)iconView;
- (void)_setupViews;
- (NSArray *)notAllowed;
- (void)setTransformedContainerView:(id)arg1;
- (BOOL)shortcutItemIsAllowed:(id)arg1;
+ (void)cancelPrepareForPotentialPresentationWithReason:(id)arg1;
- (void)_dismissAnimated:(_Bool)arg1 finishPeeking:(_Bool)arg2 ignorePresentState:(_Bool)arg3 completionHandler:(id)arg4;
@end

@interface UITouch (Private)
- (void)_setPressure:(float)arg1 resetPrevious:(BOOL)arg2;
- (float)_pathMajorRadius;
- (float)majorRadius;
- (id)_hidEvent;
@end

@interface SBIconController : UIViewController
@property(retain, nonatomic) SBApplicationShortcutMenu *presentedShortcutMenu;
+ (id)sharedInstance;
- (void)_revealMenuForIconView:(id)iconView presentImmediately:(BOOL)now;
- (void)_revealMenuForIconView:(id)iconView;
- (void)setIsEditing:(BOOL)arg1;
- (BOOL)isEditing;
- (void)_dismissShortcutMenuAnimated:(BOOL)arg1 completionHandler:(id)arg1;
- (void)_launchIcon:(id)icon;
- (void)_handleShortcutMenuPeek:(id)arg1;
- (id)presentedShortcutMenu;
- (void)applicationShortcutMenuDidPresent:(id)arg1;
@end

@interface UIApplicationShortcutItem (Private)

+ (unsigned int)_sbsActivationModeFromUIActivationMode:(unsigned int)arg1;
+ (unsigned int)_uiActivationModeFromSBSActivationMode:(unsigned int)arg1;
- (id)initWithSBSApplicationShortcutItem:(id)arg1;
@end
@interface SBSApplicationShortcutIcon : NSObject

@end

@interface SBSApplicationShortcutSystemIcon : SBSApplicationShortcutIcon
@end

@interface SBSApplicationShortcutIcon (UF)
- (id)initWithType:(UIApplicationShortcutIconType)arg1;
@end

@interface SBSApplicationShortcutContactIcon : SBSApplicationShortcutIcon
-(instancetype)initWithContactIdentifier:(NSString *)contactIdentifier;
-(instancetype)initWithFirstName:(NSString *)firstName lastName:(NSString *)lastName;
-(instancetype)initWithFirstName:(NSString *)firstName lastName:(NSString *)lastName imageData:(NSData *)imageData;
@end

@interface SBCCWiFiSetting : NSObject
- (UIImage*)glyphImageForState:(int)arg1;
@end

@interface SBSApplicationShortcutCustomImageIcon : SBSApplicationShortcutIcon
@property (nonatomic, readonly, retain) NSData *imagePNGData;
-(instancetype)initWithImagePNGData:(NSData *)imageData;
@end

@interface SBWebApplication : SBApplication
@end

@interface SBControlCenterController : UIViewController
+ (instancetype)sharedInstance;
@end
@interface SBApplicationShortcutMenuContentView : UIView
- (void)_presentForFraction:(double)arg1;
- (void)_configureForMenuPosition:(NSInteger)arg1 menuItemCount:(NSInteger)arg2;
@end

@interface WFWiFiManager : NSObject
+(id)sharedInstance;
+(void)awakeFromBundle;
-(id)knownNetworks;
-(void)scan;
@end
@interface WiFiManager : NSObject
+(instancetype)sharedInstance;
@end
@interface SBControlCenterButton : UIView
@property (nonatomic, retain) SBFolderIconView *helpIconView;
@property (nonatomic, retain) SBApplicationShortcutMenu *shortcut;
-(UIImage*)_imageFromRect:(CGRect)arg1;
- (UIImage*)sourceGlyphImage;
- (UIImage*)_backgroundImage;
- (UIImage*)_backgroundImageWithGlyphImage:(UIImage*)arg1 state:(NSInteger)arg1;
+ (instancetype)_buttonWithBGImage:(id)arg1 glyphImage:(id)arg2 naturalHeight:(float)arg3;
- (void)testMenu:(id)iconView;
- (void)testABC;
- (void)add3DTouchHelpers;
@end

@interface SBApplicationShortcutMenuItemView : UIView
@property(retain, nonatomic) SBSApplicationShortcutItem *shortcutItem;
@property (nonatomic, retain) UISwitch *DnDSwitch;
@end